package camel.rest;

public class TwitterCredentials {
    public static String consumerKey = "CZPa7rNbtr3Wh2SanXkJCzbFM";
    public static String consumerSecret = "y3xXdXXwMLT98W5AcQ30wrCAd4mtuzMGofdNoVLWmOChDQHvAn";
    public static String accessToken = "109462293-FVE3ZsczSMgVrSxhQQSWKXRHFqYaXGQXkpquZ2ZO";
    public static String accessTokenSecret = "OTfDryxAJWolLECcpkhYnia7HqOUAuBzPjLGvmjiF28nh";
}
