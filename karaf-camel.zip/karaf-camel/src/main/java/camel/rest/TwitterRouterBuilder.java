package camel.rest;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;

public class TwitterRouterBuilder extends RouteBuilder {

    @Override
    public void configure() throws Exception {
        restConfiguration().component("restlet")
                .host("localhost")
                .port(8080)
                .bindingMode(RestBindingMode.auto);

        rest("/twitter")
                .get("/user_timeline/{screen_name}").produces("application/json").to("direct:user_timeline")
                .get("/friends/{screen_name}").produces("application/json").to("direct:friends")
                .get("/users/search/{q}").produces("application/json").to("direct:userSearch")
                .get("/tweets/{q}").produces("application/json").to("direct:tweets")
        		.get("/languages/").produces("application/json").to("direct:languages")
        		.get("/privacy/").produces("application/json").to("direct:privacy")
        		.get("/configuration/").produces("application/json").to("direct:configuration")
        		.get("/suggestions/").produces("application/json").to("direct:suggestions");

        from("direct:user_timeline").bean(new TwitterService(), "getUserTimeline");
        from("direct:friends").bean(new TwitterService(), "getFriends");
        from("direct:userSearch").bean(new TwitterService(), "getUserSearch");
        from("direct:tweets").bean(new TwitterService(), "getTweets");
        from("direct:languages").bean(new TwitterService(), "getLanguage");
        from("direct:privacy").bean(new TwitterService(), "getHelp");
        from("direct:configuration").bean(new TwitterService(), "getHelpConfiguration");
        from("direct:suggestions").bean(new TwitterService(), "getUsersSuggestions");
    }
}
